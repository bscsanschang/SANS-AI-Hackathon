# analysis/

Case analysis working files live here.

The reusable command wrapper is `./analysis/run_logged`. All forensic commands must run through that wrapper.

Do not place evidence source files in this directory.
