---
description: Generate Plaso timelines, psort outputs, and timeline coverage documentation.
---

# Plaso Timeline Skill

Use this skill for timeline generation and timeline-based correlation.

## Rules

- All commands must use `./analysis/run_logged`.
- Timeline stores and exports go under `./exports/timelines/`.
- Record coverage in `./analysis/artifact_coverage.csv`.
- Do not claim an event is absent unless the timeline source coverage is documented.

## Create Timeline

```bash
./analysis/run_logged "Create timeline output directory" mkdir -p ./exports/timelines
./analysis/run_logged "Generate Plaso timeline" log2timeline.py --storage-file ./exports/timelines/<evidence_id>.plaso <source_path>
./analysis/run_logged "Inspect Plaso timeline info" pinfo.py ./exports/timelines/<evidence_id>.plaso
```

## Export Timeline

```bash
./analysis/run_logged "Export Plaso CSV" psort.py -o l2tcsv -w ./exports/timelines/<evidence_id>_timeline.csv ./exports/timelines/<evidence_id>.plaso
./analysis/run_logged "Export Plaso dynamic timeline" psort.py -o dynamic -w ./exports/timelines/<evidence_id>_timeline.txt ./exports/timelines/<evidence_id>.plaso
```

## Filter Windows of Interest

```bash
./analysis/run_logged "Filter timeline window" bash -o pipefail -lc 'psort.py -o l2tcsv ./exports/timelines/<evidence_id>.plaso "date > DATETIME(YYYY-MM-DDTHH:MM:SS+00:00) AND date < DATETIME(YYYY-MM-DDTHH:MM:SS+00:00)" > ./exports/timelines/<evidence_id>_window.csv'
```

## Correlation Discipline

- Timeline entries are observations, not a story.
- Prefer UTC and include source artifact type.
- For major findings, corroborate timeline observations with raw parser output or another independent artifact.
- If a timestamp conflict exists, preserve the conflict and downgrade confidence.
