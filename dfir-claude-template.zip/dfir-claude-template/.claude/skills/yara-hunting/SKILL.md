---
description: Build IOC registers and run cautious YARA or string sweeps across mounted evidence, memory exports, and extracted files.
---

# YARA and IOC Hunting Skill

Use this skill for IOC extraction, YARA rule generation, and local/offline sweeps.

## Rules

- All commands must use `./analysis/run_logged`.
- Use `/usr/local/bin/yara`.
- Write rules under `./analysis/yara/` and hits under `./exports/yara_hits/`.
- Build YARA rules only from confirmed indicators or clearly labeled probable indicators.
- Test false positives before broad sweeps.
- Do not upload evidence or indicators externally unless explicitly authorized.

## IOC Register

Maintain `./analysis/ioc_register.csv` with one IOC per row. Include IOC type, value, source finding, confidence, first seen UTC, last seen UTC, Evidence ID, tool output path, and notes.

## Rule Layout

```bash
./analysis/run_logged "Create YARA directories" mkdir -p ./analysis/yara ./exports/yara_hits
```

YARA metadata should include:

```text
author = "DFIR analysis agent"
source_finding = "F-###"
evidence_id = "EVID-###"
confidence = "Confirmed|Probable"
created_utc = "YYYY-MM-DDTHH:MM:SSZ"
```

## Run Scans

```bash
./analysis/run_logged "YARA syntax check" /usr/local/bin/yara ./analysis/yara/<rule>.yar ./analysis/yara/<benign_test_file>
./analysis/run_logged "YARA scan extracted files" bash -o pipefail -lc '/usr/local/bin/yara -r ./analysis/yara/<rule>.yar ./exports > ./exports/yara_hits/<rule>_exports_hits.txt'
./analysis/run_logged "YARA scan mounted evidence read-only" bash -o pipefail -lc '/usr/local/bin/yara -r ./analysis/yara/<rule>.yar /mnt/<readonly_mount> > ./exports/yara_hits/<rule>_mount_hits.txt'
```

## Interpretation

- A YARA hit is an indicator match, not proof of malware or compromise.
- Report the rule name, matched file, strings matched if available, Evidence ID, and tool output path.
- Downgrade confidence when the rule is broad, string-only, or derived from weak indicators.
