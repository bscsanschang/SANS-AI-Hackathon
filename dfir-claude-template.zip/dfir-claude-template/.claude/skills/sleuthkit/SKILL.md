---
description: Perform read-only disk image triage with Sleuth Kit, EWF tools, and mount tracking.
---

# Sleuth Kit and Disk Analysis Skill

Use this skill for disk partition analysis, file-system enumeration, read-only extraction, and mount tracking.

## Rules

- All commands must use `./analysis/run_logged`.
- Mount read-only only.
- Creating empty mount-point directories under `/mnt/` is allowed only for read-only mounting.
- Never create, delete, edit, or copy files inside mounted evidence volumes.
- Update `./analysis/mounts.csv` for every mount and unmount.

## EWF Mount Pattern

```bash
./analysis/run_logged "Create EWF mount point" sudo mkdir -p /mnt/<case>_ewf
./analysis/run_logged "Mount EWF read-only" ewfmount <image.E01> /mnt/<case>_ewf
```

Then identify the exposed raw image and partition offsets:

```bash
./analysis/run_logged "List EWF mount output" find /mnt/<case>_ewf -maxdepth 1 -type f -ls
./analysis/run_logged "Partition table from EWF raw" mmls /mnt/<case>_ewf/ewf1
```

## Filesystem Mount Pattern

Use the sector offset from `mmls`. For 512-byte sectors, byte offset is `start_sector * 512`.

```bash
./analysis/run_logged "Create filesystem mount point" sudo mkdir -p /mnt/<case>_fs_p<N>
./analysis/run_logged "Mount filesystem read-only" sudo mount -o ro,loop,show_sys_files,streams_interface=windows,offset=<byte_offset> /mnt/<case>_ewf/ewf1 /mnt/<case>_fs_p<N>
./analysis/run_logged "Verify read-only mount" bash -o pipefail -lc 'findmnt -no OPTIONS /mnt/<case>_fs_p<N> && mount | grep /mnt/<case>_fs_p<N>'
```

## Sleuth Kit Enumeration

Prefer Sleuth Kit for evidence reads when possible:

```bash
./analysis/run_logged "List root directory with fls" fls -o <sector_offset> -r -m / <image-or-ewf-raw>
./analysis/run_logged "List deleted entries" fls -o <sector_offset> -rd <image-or-ewf-raw>
./analysis/run_logged "Extract inode with icat" bash -o pipefail -lc 'icat -o <sector_offset> <image-or-ewf-raw> <inode> > ./exports/<evidence_id>_<artifact>_<inode>.bin'
```

## MACB Timeline

```bash
./analysis/run_logged "Generate bodyfile with fls" bash -o pipefail -lc 'fls -o <sector_offset> -r -m / <image-or-ewf-raw> > ./exports/<evidence_id>_bodyfile.txt'
./analysis/run_logged "Generate mactime CSV" bash -o pipefail -lc 'mactime -b ./exports/<evidence_id>_bodyfile.txt -d > ./exports/<evidence_id>_mactime.csv'
```

## Unmount

```bash
./analysis/run_logged "Unmount filesystem" sudo umount /mnt/<case>_fs_p<N>
./analysis/run_logged "Unmount EWF" sudo umount /mnt/<case>_ewf
```

If unmount fails, record the command output and reason in `./analysis/mounts.csv` and the final report limitation section.
