---
description: Generate and validate final DFIR reports, command ledger audits, artifact manifest, claim support matrix, and PDF visual quality.
---

# Report Validation Skill

Use this skill for draft reports, final reports, package audits, and PDF validation.

## Required Report Sections

The draft and final report must include executive summary, evidence examined, tools and versions, timeline of confirmed activity, findings table, IOC table, gaps and limitations, mandatory unknowns section, Claim Support Matrix, reproducibility appendix, command ledger summary, command ledger location, artifact manifest location, and confidence level definitions.

Do not use the phrase `find evil` in the final report.

## Claim Support Matrix Schema

```text
Finding ID,Claim,Claim Type,Confidence,Supporting Evidence,Tool Output Path,Alternative Explanation,Limitation
```

Claim Type must be Direct Observation, Supported Inference, or Speculative Inference.

## Pre-Report Audits

```bash
./analysis/run_logged "Audit command ledger completeness" python3 ./.claude/scripts/audit_command_ledger.py
./analysis/run_logged "Validate finding register" python3 ./.claude/scripts/validate_claims.py
./analysis/run_logged "Build artifact manifest" python3 ./.claude/scripts/build_artifact_manifest.py
```

## Sensitive Data Handling

Do not reproduce plaintext passwords, API keys, private keys, tokens, or full secrets in the final report unless explicitly required. Redact by default.

## Language Audit Terms

Search draft report text and PDF text for these terms and validate each use: attacker, compromise, compromised, malware, trojan, backdoor, keylogger, exfiltration, stolen, pass-the-hash, persistence, lateral movement, command and control, C2, beacon, spawned, installed, executed, confirmed, root cause, initial access, malicious.

For every use, decide whether the term is directly supported, an inference, or unsupported. Downgrade wording when the threshold is not met.

## PDF Visual Validation

A valid final PDF has no text off page, clipped tables, overlapping text, unreadably tiny font, or horizontal overflow caused by long hashes, paths, base64, command lines, JSON, or raw command output.

If PyMuPDF is installed:

```bash
./analysis/run_logged "Validate PDF visual sanity" python3 ./.claude/scripts/pdf_visual_check.py ./reports/final_report.pdf
```

If automated PDF validation is unavailable, perform and document manual rendered-page review.

## Stopping Condition

1. `run_logged` performs a lightweight ledger self-audit after every command.
2. Run a formal pre-report ledger audit before drafting the report.
3. After report, PDF, and manifest generation, run a final package audit.
4. The final deliverable package may include a post-report audit file newer than the PDF.
5. Do not modify the PDF after the final package audit unless another package audit is run.
