---
description: Parse and interpret Windows forensic artifacts with Zimmerman tools, event logs, registry hives, Prefetch, SRUM, LNKs, Jump Lists, Amcache, and Shimcache.
---

# Windows Artifacts Skill

Use this skill for Windows disk artifacts and parser output interpretation.

## Rules

- All commands must use `./analysis/run_logged`.
- Prefer native .NET Zimmerman tools over WINE where possible.
- Write parsed output under `./exports/windows-artifacts/`.
- Record parser coverage in `./analysis/artifact_coverage.csv`.
- Do not overstate artifact meaning.

## Common Output Setup

```bash
./analysis/run_logged "Create Windows artifact export directories" mkdir -p ./exports/windows-artifacts/{evtx,registry,prefetch,lnk,jumplists,srum,amcache,shimcache,mft,tasks}
```

## Event Logs

```bash
./analysis/run_logged "Parse EVTX with EvtxECmd" dotnet /opt/zimmermantools/EvtxeCmd/EvtxECmd.dll -d <evtx_directory> --csv ./exports/windows-artifacts/evtx --csvf <evidence_id>_evtx.csv
```

High-value event categories include process creation, PowerShell, service installation, logon activity, scheduled tasks, RDP, SMB, firewall, Defender, and AV logs. Event logs are operational evidence; correlate with process, timeline, registry, and file artifacts.

## Registry and Execution Artifacts

Use appropriate Zimmerman tools where installed. Confirm exact paths with tool inventory before execution.

Examples:

```bash
./analysis/run_logged "Parse Amcache" dotnet /opt/zimmermantools/AmcacheParser/AmcacheParser.dll -f <Amcache.hve> --csv ./exports/windows-artifacts/amcache
./analysis/run_logged "Parse Shimcache" dotnet /opt/zimmermantools/AppCompatCacheParser/AppCompatCacheParser.dll -f <SYSTEM_hive> --csv ./exports/windows-artifacts/shimcache
./analysis/run_logged "Parse SRUM" dotnet /opt/zimmermantools/SrumECmd/SrumECmd.dll -f <SRUDB.dat> --csv ./exports/windows-artifacts/srum
./analysis/run_logged "Parse Prefetch" dotnet /opt/zimmermantools/PECmd/PECmd.dll -d <Prefetch_directory> --csv ./exports/windows-artifacts/prefetch --csvf <evidence_id>_prefetch.csv
```

## Artifact Interpretation Rules

- Prefetch: execution evidence; includes recent run timestamps and referenced files.
- Shimcache/AppCompatCache: file existence or program inventory evidence on modern Windows; do not claim execution from Shimcache alone.
- Amcache: program inventory and execution-related evidence; use SHA1 for pivots when present.
- BAM/DAM: user-scoped last execution evidence where available.
- SRUM: per-application network and resource usage evidence.
- LNK and Jump Lists: access evidence; may show paths even when targets are deleted.
- Event logs: operational evidence; correlate with process, timeline, and registry artifacts.
- AV logs: direct evidence of what the AV product detected or did; not independent proof of malware family or execution.
- PowerShell EID 4104: direct evidence that script block content was logged; not proof that all payload stages succeeded.

## Hash Column Integrity

Any table column labeled MD5, SHA1, SHA-1, SHA256, or SHA-256 must contain only a valid hash, `NOT_COMPUTED`, `NOT_AVAILABLE`, `DELETED_NOT_RECOVERED`, or `SEE_APPENDIX`. Put interpretation in a separate Notes column.
