---
description: Validate findings, hypotheses, absence claims, and confidence levels before reporting.
---

# Claim Validation Skill

Use this skill before any executive summary, finding table, or final report language is produced.

## Registers

Primary finding records live in `./analysis/finding_register.jsonl` with one JSON object per finding:

```json
{
  "finding_id": "F-001",
  "claim": "",
  "claim_type": "Direct Observation",
  "confidence": "Confirmed",
  "evidence_ids": [],
  "artifact_refs": [],
  "tool_output_paths": [],
  "supporting_evidence": [],
  "contradictory_evidence": [],
  "missing_evidence": [],
  "alternative_explanations": [],
  "disproof_conditions": [],
  "limitations": [],
  "report_ready": false
}
```

## Validation Checklist

For each major finding, verify who, what, when in UTC, where, how, supporting artifact, corroborating artifact if claimed, alternative explanation, limitation, contradictory or missing evidence, confidence level, and exact tool output path.

## Confidence Downgrade Conditions

Downgrade when evidence is indirect, only one artifact supports the claim, artifacts are user-generated, timestamps conflict, interpretation depends on assumptions, or alternative explanations remain plausible.

## Absence Claims

Every absence claim must name artifact categories searched, parser/tool used, coverage start UTC, coverage end UTC, and limitations. Record absence or negative checks in `./analysis/negative_results.csv`.

## Validation Command

```bash
./analysis/run_logged "Validate finding register" python3 ./.claude/scripts/validate_claims.py
```

Use `--require-findings` only when a final report must contain at least one finding.
