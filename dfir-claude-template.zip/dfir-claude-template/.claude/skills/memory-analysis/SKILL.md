---
description: Run Volatility 3 and Memory Baseliner triage against Windows memory images with cautious claim handling.
---

# Memory Analysis Skill

Use this skill for memory image triage, process/network correlation, suspicious memory regions, and memory-backed indicators.

## Rules

- Use `python3 /opt/volatility3-2.20.0/vol.py` only.
- Do not use `/usr/local/bin/vol.py`.
- All commands must use `./analysis/run_logged`.
- Treat memory artifacts as high-weight evidence, but still require claim validation.
- If symbols fail, record the exact limitation and do not invent results.

## Baseline Commands

```bash
./analysis/run_logged "Volatility windows.info" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.info
./analysis/run_logged "Volatility pslist" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.pslist.PsList
./analysis/run_logged "Volatility psscan" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.psscan.PsScan
./analysis/run_logged "Volatility pstree" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.pstree.PsTree
./analysis/run_logged "Volatility cmdline" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.cmdline.CmdLine
./analysis/run_logged "Volatility getsids" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.getsids.GetSIDs
./analysis/run_logged "Volatility privs" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.privileges.Privs
./analysis/run_logged "Volatility netscan" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.netscan.NetScan
./analysis/run_logged "Volatility netstat" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.netstat.NetStat
./analysis/run_logged "Volatility svcscan" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.svcscan.SvcScan
./analysis/run_logged "Volatility malfind" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.malfind.Malfind
```

## Optional Exports

When dumping memory regions or process executables, write only under `./exports/memory/`:

```bash
./analysis/run_logged "Create memory export directory" mkdir -p ./exports/memory
./analysis/run_logged "Dump suspicious process memory" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> -o ./exports/memory windows.memmap.Memmap --pid <pid> --dump
```

## Interpretation

- Process listed in memory is direct evidence that Volatility identified process structures.
- Parent-child relationships from memory are strong but should be correlated with process creation logs when available.
- Network sockets in memory suggest network-capable activity at acquisition time; do not claim C2 without independent evidence.
- `malfind` is a triage signal. Do not call it malware without corroboration or recovered payload analysis.
