# DFIR Claude Code template for SANS SIFT / AI Hackathon

Put this template at the root of each case working directory that you open with Claude Code.

Recommended case layout:

```text
/cases/<case-id>/
  CLAUDE.md
  .claude/
  analysis/
  exports/
  logs/
  reports/
```

Do not put the main file in `.CLAUDE/CLAUDE.md`. Linux paths are case-sensitive, and Claude Code expects project memory at `./CLAUDE.md` or `./.claude/CLAUDE.md`.

## Install

From a clean case directory:

```bash
cd /cases/<case-id>
tar -xzf /path/to/dfir-claude-template.tar.gz --strip-components=1
chmod +x ./.claude/hooks/*.sh ./.claude/scripts/*.sh ./analysis/run_logged
./.claude/scripts/bootstrap_case.sh
```

Then start Claude Code from the same case directory:

```bash
claude
```

Inside Claude Code, verify:

```text
/memory
/hooks
/permissions
```

## Evidence outside the case directory

If evidence is outside the case directory, prefer launching Claude Code with explicit additional read access, for example:

```bash
claude --add-dir /cases/evidence
```

For persistent local-only access, copy `.claude/settings.local.example.json` to `.claude/settings.local.json`, edit the paths, and keep it uncommitted.

## First case command

The first logged command should normally be a tool inventory or evidence inventory command, for example:

```bash
./analysis/run_logged "Record SIFT kernel and host information" uname -a
./analysis/run_logged "Verify Volatility 3 path" test -f /opt/volatility3-2.20.0/vol.py
```

For any command with pipes, shell variables, globbing, heredocs, or redirection, wrap it with `bash -o pipefail -lc`:

```bash
./analysis/run_logged "Count exported EVTX files" bash -o pipefail -lc 'find ./exports -name "*.evtx" | wc -l'
```
