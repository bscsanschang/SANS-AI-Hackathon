#!/usr/bin/env bash
set -euo pipefail

input="$(cat)"
cmd="$(printf '%s' "$input" | jq -r '.tool_input.command // empty')"

# Allow already logged commands.
case "$cmd" in
  *"./analysis/run_logged "*|*" analysis/run_logged "*)
    echo '{}'
    exit 0
    ;;
esac

# Block common high-volume direct commands.
if printf '%s' "$cmd" | grep -Eq '(^|[;&|[:space:]])(cat|less|more|strings|find|grep|rg|ag)([[:space:]]|$)'; then
  jq -n --arg reason "High-volume direct command blocked. Re-run through ./analysis/run_logged and write/read only summaries or targeted excerpts." \
    '{decision:"block", reason:$reason}'
  exit 0
fi

echo '{}'