#!/usr/bin/env bash
set -euo pipefail

project_dir="${CLAUDE_PROJECT_DIR:-$PWD}"
mkdir -p "$project_dir/logs"

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
cat > "$tmp"

python3 - "$project_dir/logs/config_changes.jsonl" "$tmp" <<'PYHOOK'
import json
import sys
from datetime import datetime, timezone

out_path = sys.argv[1]
input_path = sys.argv[2]
with open(input_path, encoding="utf-8") as f:
    raw = f.read()

try:
    event = json.loads(raw)
except Exception:
    event = {"unparsed_input": raw}

record = {
    "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "event": event,
}

with open(out_path, "a", encoding="utf-8") as f:
    f.write(json.dumps(record, sort_keys=True) + "\n")
PYHOOK

exit 0
