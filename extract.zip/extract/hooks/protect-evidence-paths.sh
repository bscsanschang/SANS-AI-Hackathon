#!/usr/bin/env bash
set -euo pipefail

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
cat > "$tmp"

python3 - "$tmp" <<'PYHOOK'
import json
import os
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    raw = f.read()

try:
    data = json.loads(raw)
except Exception as exc:
    print(f"Blocked: could not parse Claude Code hook JSON input: {exc}", file=sys.stderr)
    sys.exit(2)

tool_input = data.get("tool_input", {})
keys = {"file_path", "notebook_path", "path"}
paths = []

def collect(obj):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in keys and isinstance(value, str):
                paths.append(value)
            collect(value)
    elif isinstance(obj, list):
        for item in obj:
            collect(item)

collect(tool_input)

protected_abs_prefixes = (
    "/mnt/",
    "/media/",
    "/evidence/",
    "/cases/evidence/",
)
protected_rel_prefixes = (
    "evidence/",
    "./evidence/",
    "../evidence/",
    "Evidence/",
    "./Evidence/",
    "../Evidence/",
)

for raw_path in paths:
    expanded = os.path.expanduser(raw_path)
    normalized = os.path.normpath(expanded)
    display = raw_path
    normalized_slash = normalized if normalized.endswith(os.sep) else normalized + os.sep

    if any(normalized_slash.startswith(prefix) for prefix in protected_abs_prefixes):
        print(f"Blocked: write/edit attempted against protected evidence path: {display}", file=sys.stderr)
        sys.exit(2)

    if any(raw_path == prefix.rstrip('/') or raw_path.startswith(prefix) for prefix in protected_rel_prefixes):
        print(f"Blocked: write/edit attempted against protected evidence path: {display}", file=sys.stderr)
        sys.exit(2)

sys.exit(0)
PYHOOK
