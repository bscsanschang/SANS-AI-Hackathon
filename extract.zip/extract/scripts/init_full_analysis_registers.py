#!/usr/bin/env python3
from __future__ import annotations
import csv, json
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path.cwd(); A=ROOT/'analysis'; E=ROOT/'exports'; L=ROOT/'logs'; R=ROOT/'reports'
def now(): return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def ensure_csv(path, header):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.stat().st_size==0:
        with path.open('w', newline='', encoding='utf-8') as f: csv.writer(f).writerow(header)
        return
    with path.open(newline='', encoding='utf-8', errors='replace') as f:
        rd=csv.DictReader(f); existing=list(rd.fieldnames or []); rows=list(rd)
    missing=[h for h in header if h not in existing]
    if missing:
        fields=existing+missing
        with path.open('w', newline='', encoding='utf-8') as f:
            wr=csv.DictWriter(f, fieldnames=fields); wr.writeheader()
            for row in rows:
                for m in missing: row.setdefault(m,'')
                wr.writerow(row)
def ensure_jsonl(path): path.parent.mkdir(parents=True, exist_ok=True); path.touch(exist_ok=True)
def main():
    for d in (A,E,L,R): d.mkdir(parents=True, exist_ok=True)
    state_path=A/'case_state.json'; state={}
    if state_path.exists() and state_path.stat().st_size:
        try: state=json.loads(state_path.read_text(encoding='utf-8'))
        except Exception: state={}
    state.update({'analysis_mode':'full_analysis','coverage_policy':'all_accessible_datapoints','triage_reports_allowed':False,'last_register_initialization_utc':now()})
    for k,v in {'evidence':[],'completed_steps':[],'failed_steps':[],'candidate_findings':[],'open_hypotheses':[],'known_limitations':[],'next_actions':[]}.items(): state.setdefault(k,v)
    state_path.write_text(json.dumps(state, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    ensure_csv(A/'evidence_inventory.csv',['Evidence ID','Source Path','Evidence Type','Container Type','Size Bytes','MD5','SHA1','SHA256','Verification Status','Notes'])
    ensure_csv(A/'tool_inventory.csv',['Tool','Expected Invocation','Resolved Path','Version Command','Version Output','Status','Notes'])
    ensure_csv(A/'container_inventory.csv',['Evidence ID','Container ID','Source Path','Container Type','Detected By','Output Path','Status','Notes'])
    ensure_csv(A/'volume_inventory.csv',['Evidence ID','Volume ID','Container ID','Offset','Length Bytes','Partition Type','Filesystem Type','Detected By','Status','Notes'])
    ensure_csv(A/'filesystem_inventory.csv',['Evidence ID','Filesystem ID','Volume ID','Mount Path','Filesystem Type','Read Only Verified','Object Count','Status','Notes'])
    ensure_csv(A/'data_object_inventory.csv',['Evidence ID','Object ID','Root Path','Object Path','Object Type','Size Bytes','SHA256','Signature','Extension','Detected Type','Mode','UID','GID','ATime UTC','MTime UTC','CTime UTC','Birth Time UTC','Symlink Target','Readable','Error'])
    ensure_csv(A/'parser_dispatch.csv',['Evidence ID','Object ID','Object Path','Detected Type','Parser/Method','Command Ledger Row/Ref','Output Path','Status','Limitation'])
    ensure_csv(A/'raw_scan_register.csv',['Evidence ID','Source Path','Scan Scope','Method/Tool','Command Ledger Row/Ref','Output Path','Hit Count','Status','Limitation'])
    ensure_csv(A/'artifact_coverage.csv',['Evidence ID','Scope','Category','Source Path','Method/Parser','Output Path','Coverage Start UTC','Coverage End UTC','Status','Limitations'])
    ensure_csv(A/'mounts.csv',['Evidence ID','EWF Mount Path','Filesystem Mount Path','Offset','Mount Options','Mounted UTC','Unmounted UTC','Status'])
    ensure_csv(A/'hypothesis_register.csv',['Hypothesis ID','Hypothesis','Current Support','Contradictory Evidence','Needed Validation','Status'])
    ensure_csv(A/'negative_results.csv',['Negative ID','Evidence ID','Question','Scope Searched','Tool/Parser','Command Ledger Row/Ref','Output Path','Coverage Start UTC','Coverage End UTC','Result','Limitations'])
    ensure_csv(A/'ioc_register.csv',['IOC ID','IOC Type','Value','Source Finding ID','Confidence','First Observed UTC','Last Observed UTC','Evidence ID','Source Artifact','Notes'])
    ensure_jsonl(A/'finding_register.jsonl'); ensure_jsonl(R/'self_correction_log.jsonl')
    print('Universal full-analysis registers initialized or upgraded.'); return 0
if __name__=='__main__': raise SystemExit(main())
