#!/usr/bin/env bash
set -euo pipefail

mkdir -p ./analysis ./exports ./logs ./reports
chmod +x ./analysis/run_logged ./.claude/hooks/*.sh ./.claude/scripts/*.sh

./analysis/run_logged "Initialize DFIR registers" python3 ./.claude/scripts/init_registers.py
./analysis/run_logged "Record bootstrap file layout" bash -o pipefail -lc 'find . -maxdepth 3 \( -path "./analysis/*" -o -path "./exports/*" -o -path "./logs/*" -o -path "./reports/*" -o -path "./.claude/*" -o -name "CLAUDE.md" \) -print | sort'

echo "DFIR Claude Code case workspace initialized."
echo "Next: run /memory, /hooks, and /permissions inside Claude Code to verify loading."
