#!/usr/bin/env python3
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
ANALYSIS = ROOT / "analysis"
REPORTS = ROOT / "reports"
LOGS = ROOT / "logs"
EXPORTS = ROOT / "exports"

for directory in (ANALYSIS, REPORTS, LOGS, EXPORTS):
    directory.mkdir(parents=True, exist_ok=True)


def write_csv_if_missing(path: Path, header):
    if path.exists():
        return False
    with path.open("w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(header)
    return True

created = []

csv_specs = {
    ANALYSIS / "evidence_inventory.csv": [
        "Evidence ID", "Source Path", "Evidence Type", "Size Bytes", "MD5", "SHA1", "SHA256", "Verification Status", "Notes"
    ],
    ANALYSIS / "tool_inventory.csv": [
        "Tool", "Expected Invocation", "Resolved Path", "Version Command", "Version Output", "Status", "Notes"
    ],
    ANALYSIS / "mounts.csv": [
        "Evidence ID", "EWF Mount Path", "Filesystem Mount Path", "Offset", "Mount Options", "Mounted UTC", "Unmounted UTC", "Status"
    ],
    ANALYSIS / "artifact_coverage.csv": [
        "Evidence ID", "Host", "Artifact Category", "Source Path", "Parser", "Output Path", "Coverage Start UTC", "Coverage End UTC", "Status", "Limitations"
    ],
    ANALYSIS / "hypothesis_register.csv": [
        "Hypothesis ID", "Created UTC", "Status", "Hypothesis", "Supporting Evidence", "Contradictory Evidence", "Next Validation Step", "Resolution UTC", "Notes"
    ],
    ANALYSIS / "negative_results.csv": [
        "Evidence ID", "Question", "Artifact Category", "Tool", "Command Ledger Row", "Output Path", "Coverage Start UTC", "Coverage End UTC", "Result", "Limitations"
    ],
    ANALYSIS / "ioc_register.csv": [
        "IOC ID", "Type", "Value", "Source Finding ID", "Confidence", "First Seen UTC", "Last Seen UTC", "Evidence ID", "Tool Output Path", "Notes"
    ],
}

for path, header in csv_specs.items():
    if write_csv_if_missing(path, header):
        created.append(str(path))

finding_path = ANALYSIS / "finding_register.jsonl"
if not finding_path.exists():
    finding_path.write_text("", encoding="utf-8")
    created.append(str(finding_path))

self_correction_path = REPORTS / "self_correction_log.jsonl"
if not self_correction_path.exists():
    self_correction_path.write_text("", encoding="utf-8")
    created.append(str(self_correction_path))

case_state_path = ANALYSIS / "case_state.json"
if not case_state_path.exists():
    state = {
        "case_id": "",
        "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "active_phase": "bootstrap",
        "evidence": [],
        "mounts": [],
        "completed_steps": ["workspace_bootstrap"],
        "failed_steps": [],
        "candidate_findings": [],
        "open_hypotheses": [],
        "known_limitations": [],
        "next_actions": ["verify tool inventory", "inventory evidence"],
    }
    case_state_path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    created.append(str(case_state_path))

print("Initialized DFIR registers.")
if created:
    print("Created:")
    for item in created:
        print(f"- {item}")
else:
    print("No new register files were required.")
