#!/usr/bin/env python3
import csv
import hashlib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUTPUT = ROOT / "reports" / "artifact_manifest.csv"
SCAN_DIRS = [ROOT / "analysis", ROOT / "exports", ROOT / "logs", ROOT / "reports"]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def classify(path: Path) -> str:
    suffix = path.suffix.lower()
    if path.name == "command_ledger.csv":
        return "command-ledger"
    if suffix == ".csv":
        return "csv"
    if suffix == ".jsonl":
        return "jsonl"
    if suffix == ".json":
        return "json"
    if suffix == ".md":
        return "markdown"
    if suffix == ".pdf":
        return "pdf"
    if suffix in {".log", ".txt"}:
        return "log"
    if suffix in {".plaso"}:
        return "timeline-store"
    return "artifact"

rows = []
for directory in SCAN_DIRS:
    if not directory.exists():
        continue
    for path in sorted(p for p in directory.rglob("*") if p.is_file()):
        rel = path.relative_to(ROOT)
        stat = path.stat()
        if path.resolve() == OUTPUT.resolve():
            digest = "NOT_COMPUTED"
            purpose = "Artifact manifest; self-hash is intentionally not computed."
        else:
            digest = sha256_file(path)
            purpose = "Generated case analysis artifact"
        rows.append([
            str(rel),
            classify(path),
            stat.st_size,
            digest,
            datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            purpose,
        ])

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with OUTPUT.open("w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Path", "Type", "Size Bytes", "SHA256", "Created UTC", "Purpose"])
    writer.writerows(rows)

print(f"Wrote {OUTPUT} with {len(rows)} rows.")
