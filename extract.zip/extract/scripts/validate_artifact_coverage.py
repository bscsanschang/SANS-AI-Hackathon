#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
ROOT=Path.cwd(); A=ROOT/'analysis'
REQUIRED=[
'Evidence source inventory','Evidence integrity verification','Tool inventory','Container identification','Archive/container recursive expansion or logged blocker','Partition and volume enumeration','Filesystem detection','Filesystem metadata enumeration','File and directory inventory','Alternate data streams / extended attributes / resource forks where supported','Deleted object enumeration','Unallocated and slack/free-space scan or logged blocker','Per-object hashing','Per-object file type identification','Type-specific parser dispatch','Generic unsupported-type scan','Raw byte scan','Strings/text extraction','IOC/YARA/signature sweep or logged tool-missing blocker','Bulk feature extraction or logged tool-missing blocker','Timeline/bodyfile generation','OS detection','OS-specific artifact sweep for every detected OS','User/account artifact sweep','Log artifact sweep','Network artifact sweep','Persistence/autostart artifact sweep','Executable/script/static-analysis sweep','Database artifact sweep','Browser/application artifact sweep','Memory analysis if memory evidence exists; otherwise Not Present','Packet capture analysis if packet evidence exists; otherwise Not Present','Cloud/sync/application artifact sweep where artifacts exist','Negative-results register update','Finding register update','Claim validation','Command ledger audit','Artifact manifest generation','Final package audit']
ACCEPT={'complete','parsed','scanned','enumerated','verified','hashed','carved','timeline generated','not present','not applicable','unsupported - generic scanned','tool missing - blocked','access blocked - logged','parser failed - logged','corrupt - logged','encrypted - logged'}
BAD={'','skipped','not parsed','not run','pending','deferred','out of scope','triage only','triage window','partial'}
NEED_OUT={'complete','parsed','scanned','enumerated','verified','hashed','carved','timeline generated','unsupported - generic scanned'}
NEED_LIMIT={'tool missing - blocked','access blocked - logged','parser failed - logged','corrupt - logged','encrypted - logged'}
ALIASES={'file/object inventory':'File and directory inventory','data object inventory':'File and directory inventory','object inventory':'File and directory inventory','file type identification':'Per-object file type identification','hashing':'Per-object hashing','parser dispatch':'Type-specific parser dispatch','timeline generation':'Timeline/bodyfile generation','yara scan':'IOC/YARA/signature sweep or logged tool-missing blocker','ioc sweep':'IOC/YARA/signature sweep or logged tool-missing blocker','bulk extractor':'Bulk feature extraction or logged tool-missing blocker','event logs':'Log artifact sweep','logs':'Log artifact sweep','memory analysis':'Memory analysis if memory evidence exists; otherwise Not Present','pcap analysis':'Packet capture analysis if packet evidence exists; otherwise Not Present'}
def norm(x): return ' '.join((x or '').strip().lower().split())
def canon(x):
    n=norm(x)
    if n in ALIASES: return ALIASES[n]
    for c in REQUIRED:
        if norm(c)==n: return c
    return (x or '').strip()
def read_csv(p):
    if not p.exists(): return []
    with p.open(newline='', encoding='utf-8', errors='replace') as f: return list(csv.DictReader(f))
def val(row, keys):
    for k in keys:
        if row.get(k): return row[k]
    return ''
def path_ok(s):
    if not s: return False
    for part in [p.strip() for p in s.replace('\n',';').split(';') if p.strip()]:
        u=part.upper()
        if u.startswith(('P-','APPENDIX','LEDGER','ROW ')): return True
        p=Path(part); p=p if p.is_absolute() else ROOT/p
        if p.exists(): return True
    return False
def evidence_ids():
    ids=[]
    for r in read_csv(A/'evidence_inventory.csv'):
        eid=val(r,['Evidence ID','EvidenceID','evidence_id']).strip()
        if eid and eid not in ids: ids.append(eid)
    return ids
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--full-analysis',action='store_true'); ap.add_argument('--coverage',default='./analysis/artifact_coverage.csv'); ap.add_argument('--list-required',action='store_true'); args=ap.parse_args()
    if args.list_required:
        print('\n'.join(REQUIRED)); return 0
    errors=[]; warnings=[]
    sp=A/'case_state.json'
    if not sp.exists(): errors.append('Missing ./analysis/case_state.json')
    else:
        try: st=json.loads(sp.read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'case_state.json invalid: {e}'); st={}
        if args.full_analysis and st.get('analysis_mode')!='full_analysis': errors.append(f"analysis_mode must be full_analysis, got {st.get('analysis_mode')!r}")
        if st.get('triage_reports_allowed') not in (False,'false','False',0): errors.append('triage_reports_allowed must be false')
    rows=read_csv(Path(args.coverage))
    if not rows: errors.append(f'No coverage rows found in {args.coverage}')
    by={}
    for i,r in enumerate(rows,start=2):
        cat=canon(val(r,['Category','Artifact Category'])); status=norm(val(r,['Status'])); out=val(r,['Output Path','Tool Output Path']); lim=val(r,['Limitations','Limitation','Notes']); eid=val(r,['Evidence ID']); scope=val(r,['Scope','Host'])
        if not cat: errors.append(f'Coverage row {i}: missing Category'); continue
        by.setdefault(cat,[]).append(r)
        if status in BAD: errors.append(f'Coverage row {i} ({cat}): invalid final status {status!r}')
        elif status not in ACCEPT: errors.append(f'Coverage row {i} ({cat}): status {status!r} is not accepted')
        if status in NEED_OUT and not path_ok(out): errors.append(f'Coverage row {i} ({cat}): status {status!r} requires existing Output Path or appendix/ledger reference')
        if status in NEED_LIMIT and not (lim.strip() or out.strip()): errors.append(f'Coverage row {i} ({cat}): blocker status requires limitation and/or output path')
        if not eid: warnings.append(f'Coverage row {i} ({cat}): missing Evidence ID')
        if not scope: warnings.append(f'Coverage row {i} ({cat}): missing Scope')
    for c in REQUIRED:
        if c not in by: errors.append(f'Missing required coverage category: {c}')
    ids=evidence_ids(); globals={'case','all','global','n/a','not applicable'}
    if ids:
        for c in REQUIRED:
            reps={norm(val(r,['Evidence ID'])) for r in by.get(c,[])}
            if not (reps & globals):
                for eid in ids:
                    if norm(eid) not in reps: errors.append(f"Category {c!r} missing row for Evidence ID {eid!r}")
    if warnings:
        print('WARNINGS:'); [print('- '+w) for w in warnings]; print()
    if errors:
        print('ERROR: full-analysis artifact coverage validation failed.'); [print('- '+e) for e in errors]; print('\nRequired categories:'); [print('- '+c) for c in REQUIRED]; return 1
    print('Full-analysis artifact coverage validation passed.'); print(f'Coverage rows: {len(rows)}'); print(f'Required categories satisfied: {len(REQUIRED)}'); return 0
if __name__=='__main__': raise SystemExit(main())
