#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import os
from collections import Counter

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("csv_path")
    p.add_argument("--out", required=True)
    p.add_argument("--sample-rows", type=int, default=5)
    args = p.parse_args()

    result = {
        "path": os.path.abspath(args.csv_path),
        "size_bytes": os.path.getsize(args.csv_path),
        "sha256": sha256_file(args.csv_path),
        "columns": [],
        "row_count": 0,
        "sample_rows": [],
        "non_empty_counts": {},
        "top_values": {}
    }

    with open(args.csv_path, newline="", errors="replace") as f:
        reader = csv.DictReader(f)
        result["columns"] = reader.fieldnames or []
        non_empty = Counter()
        top = {c: Counter() for c in result["columns"][:20]}

        for row in reader:
            result["row_count"] += 1
            if len(result["sample_rows"]) < args.sample_rows:
                result["sample_rows"].append(row)

            for c in result["columns"]:
                v = (row.get(c) or "").strip()
                if v:
                    non_empty[c] += 1
                    if c in top:
                        top[c][v[:200]] += 1

        result["non_empty_counts"] = dict(non_empty)
        result["top_values"] = {
            c: counter.most_common(10)
            for c, counter in top.items()
            if counter
        }

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2, sort_keys=True)

if __name__ == "__main__":
    main()