#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv
from datetime import datetime,timezone
from pathlib import Path
H=['Evidence ID','Scope','Category','Source Path','Method/Parser','Output Path','Coverage Start UTC','Coverage End UTC','Status','Limitations']
def now(): return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def main():
    p=argparse.ArgumentParser(); p.add_argument('--evidence-id',required=True); p.add_argument('--scope',required=True); p.add_argument('--category',required=True); p.add_argument('--source-path',default=''); p.add_argument('--method',required=True); p.add_argument('--output-path',default=''); p.add_argument('--status',required=True); p.add_argument('--limitations',default=''); p.add_argument('--start-utc',default=''); p.add_argument('--end-utc',default=''); p.add_argument('--coverage',default='./analysis/artifact_coverage.csv'); a=p.parse_args()
    path=Path(a.coverage); path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists() or path.stat().st_size==0:
        with path.open('w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(H)
    with path.open('a',newline='',encoding='utf-8') as f:
        csv.DictWriter(f,fieldnames=H).writerow({'Evidence ID':a.evidence_id,'Scope':a.scope,'Category':a.category,'Source Path':a.source_path,'Method/Parser':a.method,'Output Path':a.output_path,'Coverage Start UTC':a.start_utc or now(),'Coverage End UTC':a.end_utc or now(),'Status':a.status,'Limitations':a.limitations})
    print(f'Appended coverage row: {a.category} -> {a.status}'); return 0
if __name__=='__main__': raise SystemExit(main())
