#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv
from pathlib import Path
HEADER=['Evidence ID','Object ID','Object Path','Detected Type','Extension','Priority','Suggested Parser/Method','Generic Fallback','Notes']
EXT={'.evtx':('High','EvtxECmd or Plaso log2timeline','strings + raw grep','Windows event log'),'.pf':('High','PECmd or Plaso','strings + metadata','Windows Prefetch'),'.lnk':('High','LECmd or Plaso','strings','Windows LNK'),'.pcap':('High','tshark/capinfos/zeek','strings','Packet capture'),'.pcapng':('High','tshark/capinfos/zeek','strings','Packet capture'),'.sqlite':('High','sqlite3 schema/tables export on copied file','strings','SQLite'),'.db':('Medium','sqlite3 if SQLite; otherwise file-specific parser','strings','Database-like'),'.log':('Medium','text parser/grep/ripgrep','strings','Log'),'.json':('Medium','jq/python JSON validation','strings','JSON'),'.xml':('Medium','xmllint/python XML parser','strings','XML'),'.zip':('High','archive list/extract to ./exports then recursive analysis','hash + strings','Archive'),'.7z':('High','7z list/extract to ./exports then recursive analysis','hash + strings','Archive'),'.rar':('High','rar/unrar list/extract to ./exports then recursive analysis','hash + strings','Archive')}
def choose(det,ext):
    e=(ext or '').lower(); d=(det or '').lower()
    if e in EXT: return EXT[e]
    if 'sqlite' in d: return 'High','sqlite3 schema/tables export on copied file','strings','SQLite'
    if 'zip' in d or 'archive' in d: return 'High','archive list/extract to ./exports then recursive analysis','hash + strings','Archive/container'
    if 'pdf' in d: return 'Medium','pdfinfo/exiftool/pdftotext if available','strings','PDF'
    if 'pe executable' in d or 'elf' in d or 'mach-o' in d: return 'High','static executable triage: file/hash/strings/imports/YARA','strings + hash','Executable'
    if 'text' in d or 'json' in d or 'xml' in d or 'log' in d: return 'Medium','structured/text parser + grep/ripgrep','strings','Text/log/config'
    return 'Low','No type-specific parser identified','metadata + hash + signature + generic byte/string scan + IOC/YARA if available','Unsupported file type; generic scan required'
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory',default='./analysis/data_object_inventory.csv'); ap.add_argument('--output',default='./analysis/parser_workqueue.csv'); args=ap.parse_args()
    inv=Path(args.inventory)
    if not inv.exists(): print(f'ERROR inventory missing: {inv}'); return 2
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True); n=0
    with inv.open(newline='',encoding='utf-8',errors='replace') as f,out.open('w',newline='',encoding='utf-8') as g:
        rd=csv.DictReader(f); wr=csv.DictWriter(g,fieldnames=HEADER); wr.writeheader()
        for r in rd:
            if r.get('Object Type')!='file': continue
            n+=1; pri,parser,fb,notes=choose(r.get('Detected Type',''),r.get('Extension',''))
            wr.writerow({'Evidence ID':r.get('Evidence ID',''),'Object ID':r.get('Object ID',''),'Object Path':r.get('Object Path',''),'Detected Type':r.get('Detected Type',''),'Extension':r.get('Extension',''),'Priority':pri,'Suggested Parser/Method':parser,'Generic Fallback':fb,'Notes':notes})
    print(f'Parser workqueue written: {out.resolve()}'); print(f'File objects queued: {n}'); return 0
if __name__=='__main__': raise SystemExit(main())
