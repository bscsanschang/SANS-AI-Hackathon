#!/usr/bin/env python3
import argparse
import csv
import json
import os
import re

def main():
    p = argparse.ArgumentParser()
    p.add_argument("csv_path")
    p.add_argument("--regex", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--max-rows", type=int, default=100)
    args = p.parse_args()

    rx = re.compile(args.regex, re.IGNORECASE)
    rows = []

    with open(args.csv_path, newline="", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            haystack = json.dumps(row, sort_keys=True)
            if rx.search(haystack):
                rows.append(row)
                if len(rows) >= args.max_rows:
                    break

    out = {
        "source": os.path.abspath(args.csv_path),
        "regex": args.regex,
        "max_rows": args.max_rows,
        "returned_rows": len(rows),
        "rows": rows
    }

    with open(args.out, "w") as f:
        json.dump(out, f, indent=2, sort_keys=True)

if __name__ == "__main__":
    main()