#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,os,stat,sys
from datetime import datetime,timezone
from pathlib import Path
HEADER=['Evidence ID','Object ID','Root Path','Object Path','Object Type','Size Bytes','SHA256','Signature','Extension','Detected Type','Mode','UID','GID','ATime UTC','MTime UTC','CTime UTC','Birth Time UTC','Symlink Target','Readable','Error']
COV=['Evidence ID','Scope','Category','Source Path','Method/Parser','Output Path','Coverage Start UTC','Coverage End UTC','Status','Limitations']
SIGS=[(b'MZ','Windows PE executable or DLL'),(b'\x7fELF','ELF executable/shared object'),(b'PK\x03\x04','ZIP/OpenXML/JAR/APK archive'),(b'7z\xbc\xaf\x27\x1c','7-Zip archive'),(b'Rar!\x1a\x07','RAR archive'),(b'\x1f\x8b','Gzip compressed data'),(b'%PDF-','PDF document'),(b'SQLite format 3\x00','SQLite database'),(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1','OLE Compound File'),(b'\x89PNG\r\n\x1a\n','PNG image'),(b'\xff\xd8\xff','JPEG image'),(b'regf','Windows Registry hive'),(b'ElfFile\x00','Windows EVTX log')]
EXT={'.evtx':'Windows EVTX log','.pf':'Windows Prefetch file','.lnk':'Windows shortcut/LNK','.sqlite':'SQLite database','.sqlite3':'SQLite database','.db':'Database file','.pcap':'Packet capture','.pcapng':'Packet capture','.json':'JSON text','.xml':'XML text','.log':'Log text','.txt':'Plain text','.csv':'CSV text','.ps1':'PowerShell script','.bat':'Windows batch script','.cmd':'Windows command script','.py':'Python script','.sh':'Shell script','.exe':'Executable file','.dll':'Executable library','.zip':'ZIP archive','.7z':'7-Zip archive','.rar':'RAR archive','.pdf':'PDF document','.docx':'Office OpenXML document','.xlsx':'Office OpenXML spreadsheet','.pptx':'Office OpenXML presentation'}
def utc(t): return datetime.fromtimestamp(t,timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def now(): return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def ensure(path,header):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists() or path.stat().st_size==0:
        with path.open('w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(header)
def typ(m):
    return 'file' if stat.S_ISREG(m) else 'directory' if stat.S_ISDIR(m) else 'symlink' if stat.S_ISLNK(m) else 'block_device' if stat.S_ISBLK(m) else 'char_device' if stat.S_ISCHR(m) else 'fifo' if stat.S_ISFIFO(m) else 'socket' if stat.S_ISSOCK(m) else 'other'
def oid(eid,root,path): return 'OBJ-'+hashlib.sha1(f'{eid}\0{root}\0{path}'.encode('utf-8','replace')).hexdigest()[:16]
def sig(path,isfile):
    if not isfile: return '',''
    try: h=path.open('rb').read(64)
    except Exception as e: return '',f'UNREADABLE: {type(e).__name__}'
    det=''
    for s,l in SIGS:
        if h.startswith(s): det=l; break
    if not det and len(h)>=12 and h[4:8]==b'ftyp': det='ISO Base Media/MP4 container'
    if not det: det=EXT.get(path.suffix.lower(),'Unknown/unsupported')
    return h[:32].hex(),det
def sha(path):
    h=hashlib.sha256(); total=0
    try:
        with path.open('rb') as f:
            for b in iter(lambda:f.read(1048576),b''):
                h.update(b); total+=len(b)
        return h.hexdigest(),None,total
    except Exception as e: return '',f'{type(e).__name__}: {e}',total
def walk(root,follow=False):
    stack=[root]
    while stack:
        p=stack.pop(); yield p
        try: st=p.stat() if follow else p.lstat()
        except Exception: continue
        if not stat.S_ISDIR(st.st_mode): continue
        try:
            entries=sorted([Path(e.path) for e in os.scandir(p)],key=str)
            stack.extend(reversed(entries))
        except Exception: continue
def append_cov(path,rows):
    ensure(path,COV)
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=COV)
        for r in rows: w.writerow({k:r.get(k,'') for k in COV})
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',action='append',required=True); ap.add_argument('--evidence-id',required=True); ap.add_argument('--inventory',default='./analysis/data_object_inventory.csv'); ap.add_argument('--coverage',default='./analysis/artifact_coverage.csv'); ap.add_argument('--hash',choices=['none','sha256'],default='sha256'); ap.add_argument('--follow-links',action='store_true'); args=ap.parse_args()
    inv=Path(args.inventory); ensure(inv,HEADER); started=now(); total=files=dirs=unread=hashed=0
    with inv.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=HEADER)
        for rs in args.root:
            root=Path(rs).resolve()
            if not root.exists(): print(f'ERROR root missing: {root}',file=sys.stderr); return 2
            for p in walk(root,args.follow_links):
                total+=1; err=''; readable='YES'
                try: st=p.stat() if args.follow_links else p.lstat(); ot=typ(st.st_mode); files+=ot=='file'; dirs+=ot=='directory'
                except Exception as e: st=None; ot='unknown'; err=f'stat failed: {type(e).__name__}: {e}'; readable='NO'; unread+=1
                isreg=bool(st and stat.S_ISREG(st.st_mode)); link=''
                if st and stat.S_ISLNK(st.st_mode):
                    try: link=os.readlink(p)
                    except Exception as e: err=(err+'; ' if err else '')+f'readlink failed: {e}'
                signature,det=sig(p,isreg); digest=''
                if args.hash=='sha256' and isreg:
                    digest,he,hb=sha(p); hashed+=hb
                    if he: err=(err+'; ' if err else '')+'hash failed: '+he; readable='NO'; unread+=1
                row={'Evidence ID':args.evidence_id,'Object ID':oid(args.evidence_id,root,p),'Root Path':str(root),'Object Path':str(p),'Object Type':ot,'Size Bytes':str(st.st_size) if st else '', 'SHA256':digest if digest else ('NOT_COMPUTED' if isreg and args.hash=='none' else ''),'Signature':signature,'Extension':p.suffix.lower(),'Detected Type':det,'Mode':oct(stat.S_IMODE(st.st_mode)) if st else '','UID':str(st.st_uid) if st else '','GID':str(st.st_gid) if st else '','ATime UTC':utc(st.st_atime) if st else '','MTime UTC':utc(st.st_mtime) if st else '','CTime UTC':utc(st.st_ctime) if st else '','Birth Time UTC':utc(getattr(st,'st_birthtime')) if st and hasattr(st,'st_birthtime') else '','Symlink Target':link,'Readable':readable,'Error':err}
                w.writerow(row)
    ended=now(); roots='; '.join(str(Path(r).resolve()) for r in args.root); lim=f'Unreadable objects recorded: {unread}; symlinks followed: {args.follow_links}; objects: {total}; dirs: {dirs}; files: {files}.'
    append_cov(Path(args.coverage),[
      {'Evidence ID':args.evidence_id,'Scope':roots,'Category':'File and directory inventory','Source Path':roots,'Method/Parser':'enumerate_datapoints.py','Output Path':str(inv.resolve()),'Coverage Start UTC':started,'Coverage End UTC':ended,'Status':'Enumerated','Limitations':lim},
      {'Evidence ID':args.evidence_id,'Scope':roots,'Category':'Per-object hashing','Source Path':roots,'Method/Parser':'enumerate_datapoints.py sha256','Output Path':str(inv.resolve()),'Coverage Start UTC':started,'Coverage End UTC':ended,'Status':'Hashed' if args.hash=='sha256' else 'Not Applicable','Limitations':lim+f' Hashed bytes: {hashed}.'},
      {'Evidence ID':args.evidence_id,'Scope':roots,'Category':'Per-object file type identification','Source Path':roots,'Method/Parser':'signature and extension detection','Output Path':str(inv.resolve()),'Coverage Start UTC':started,'Coverage End UTC':ended,'Status':'Complete','Limitations':'Signature detection is heuristic; parser_dispatch.csv records parser results.'}])
    print(f'Enumerated objects: {total}'); print(f'Regular files: {files}'); print(f'Directories: {dirs}'); print(f'Unreadable objects: {unread}'); print(f'Total hashed bytes: {hashed}'); print(f'Inventory: {inv.resolve()}'); return 0
if __name__=='__main__': raise SystemExit(main())
