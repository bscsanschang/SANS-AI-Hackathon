#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,re
from datetime import datetime,timezone
from pathlib import Path
HITS=['Evidence ID','Object ID','Object Path','Pattern','Approx Offset','Value Preview','Value SHA256']
SUMMARY=['Evidence ID','Object ID','Object Path','Size Bytes','Bytes Scanned','Hit Count','Status','Error']
RAW=['Evidence ID','Source Path','Scan Scope','Method/Tool','Command Ledger Row/Ref','Output Path','Hit Count','Status','Limitation']
COV=['Evidence ID','Scope','Category','Source Path','Method/Parser','Output Path','Coverage Start UTC','Coverage End UTC','Status','Limitations']
PATS=[('url',re.compile(rb'(?i)\b(?:https?|ftp)://[^\s"\'<>]{4,}')),('email',re.compile(rb'(?i)\b[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}\b')),('ipv4',re.compile(rb'\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b')),('private_key_header',re.compile(rb'-----BEGIN [A-Z0-9 ]{1,40}PRIVATE KEY-----')),('credential_keyword',re.compile(rb'(?i)\b(?:password|passwd|pwd|token|secret|api[_-]?key|credential|bearer)\b')),('base64_like',re.compile(rb'(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{40,}={0,2}(?![A-Za-z0-9+/=])'))]
def now(): return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def ensure(p,h):
    p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists() or p.stat().st_size==0:
        with p.open('w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(h)
def prev(b): return b[:120].decode('utf-8','replace').replace('\r','\\r').replace('\n','\\n').replace('\t','\\t')
def vh(b): return hashlib.sha256(b).hexdigest()
def scan(path,writer,row,chunk,cap):
    total=hits=0; overlap=b''
    try:
        with path.open('rb') as f:
            base=0
            while True:
                c=f.read(chunk)
                if not c: break
                data=overlap+c; scanbase=base-len(overlap); total+=len(c)
                for name,pat in PATS:
                    for m in pat.finditer(data):
                        if cap and hits>=cap: continue
                        val=m.group(0); writer.writerow({'Evidence ID':row.get('Evidence ID',''),'Object ID':row.get('Object ID',''),'Object Path':row.get('Object Path',''),'Pattern':name,'Approx Offset':str(max(scanbase+m.start(),0)),'Value Preview':prev(val),'Value SHA256':vh(val)}); hits+=1
                overlap=data[-4096:]; base+=len(c)
        return total,hits,''
    except Exception as e: return total,hits,f'{type(e).__name__}: {e}'
def append_raw(p,eid,src,out,hits,status,lim):
    ensure(p,RAW)
    with p.open('a',newline='',encoding='utf-8') as f: csv.DictWriter(f,fieldnames=RAW).writerow({'Evidence ID':eid,'Source Path':src,'Scan Scope':'All files listed in data_object_inventory.csv','Method/Tool':'generic_scan_datapoints.py byte regex/string scan','Command Ledger Row/Ref':'See command_ledger.csv row for this invocation','Output Path':str(out.resolve()),'Hit Count':str(hits),'Status':status,'Limitation':lim})
def append_cov(p,eid,src,out,start,end,files,unread):
    ensure(p,COV); lim=f'Generic byte-pattern scan over file inventory. Files scanned: {files}; unreadable files: {unread}. Values previewed and SHA256-hashed. Type-specific parsers still required.'
    with p.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=COV)
        for cat,status in [('Raw byte scan','Scanned'),('Strings/text extraction','Scanned'),('Generic unsupported-type scan','Unsupported - Generic Scanned')]:
            w.writerow({'Evidence ID':eid,'Scope':'All inventoried file objects','Category':cat,'Source Path':src,'Method/Parser':'generic_scan_datapoints.py','Output Path':str(out.resolve()),'Coverage Start UTC':start,'Coverage End UTC':end,'Status':status,'Limitations':lim})
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory',default='./analysis/data_object_inventory.csv'); ap.add_argument('--output-dir',default='./exports/generic_scan'); ap.add_argument('--evidence-id',default='ALL'); ap.add_argument('--chunk-size',type=int,default=1048576); ap.add_argument('--max-hits-per-file',type=int,default=1000); ap.add_argument('--coverage',default='./analysis/artifact_coverage.csv'); ap.add_argument('--raw-scan-register',default='./analysis/raw_scan_register.csv'); args=ap.parse_args()
    inv=Path(args.inventory)
    if not inv.exists(): print(f'ERROR inventory missing: {inv}'); return 2
    od=Path(args.output_dir); od.mkdir(parents=True,exist_ok=True); hits_p=od/'generic_scan_hits.csv'; summ_p=od/'generic_scan_summary.csv'; start=now(); total_files=unread=total_hits=total_bytes=0
    with inv.open(newline='',encoding='utf-8',errors='replace') as f,hits_p.open('w',newline='',encoding='utf-8') as hf,summ_p.open('w',newline='',encoding='utf-8') as sf:
        rd=csv.DictReader(f); hw=csv.DictWriter(hf,fieldnames=HITS); sw=csv.DictWriter(sf,fieldnames=SUMMARY); hw.writeheader(); sw.writeheader()
        for row in rd:
            if row.get('Object Type')!='file': continue
            p=Path(row.get('Object Path','')); total_files+=1; bs,h,e=scan(p,hw,row,args.chunk_size,args.max_hits_per_file); total_bytes+=bs; total_hits+=h; unread+=bool(e); sw.writerow({'Evidence ID':row.get('Evidence ID',''),'Object ID':row.get('Object ID',''),'Object Path':str(p),'Size Bytes':row.get('Size Bytes',''),'Bytes Scanned':str(bs),'Hit Count':str(h),'Status':'Scanned' if not e else 'Access Blocked - Logged','Error':e})
    end=now(); status='Scanned' if unread==0 else 'Access Blocked - Logged'; lim=f'Unreadable files: {unread}; total bytes scanned: {total_bytes}; hit cap per file: {args.max_hits_per_file}.'
    append_raw(Path(args.raw_scan_register),args.evidence_id,str(inv.resolve()),hits_p,total_hits,status,lim); append_cov(Path(args.coverage),args.evidence_id,str(inv.resolve()),hits_p,start,end,total_files,unread)
    print(f'Generic scan complete. Files scanned: {total_files}'); print(f'Unreadable files: {unread}'); print(f'Bytes scanned: {total_bytes}'); print(f'Hits: {total_hits}'); print(f'Hits CSV: {hits_p.resolve()}'); print(f'Summary CSV: {summ_p.resolve()}'); return 0
if __name__=='__main__': raise SystemExit(main())
