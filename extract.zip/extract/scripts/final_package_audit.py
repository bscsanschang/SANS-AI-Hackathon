#!/usr/bin/env python3
from __future__ import annotations
import csv,json,re
from pathlib import Path
ROOT=Path.cwd(); A=ROOT/'analysis'; L=ROOT/'logs'; R=ROOT/'reports'
REQUIRED=[A/'case_state.json',A/'evidence_inventory.csv',A/'tool_inventory.csv',A/'artifact_coverage.csv',A/'data_object_inventory.csv',A/'parser_dispatch.csv',A/'raw_scan_register.csv',A/'finding_register.jsonl',A/'negative_results.csv',A/'ioc_register.csv',L/'command_ledger.csv',R/'artifact_manifest.csv']
BAD=[r'\bshort triage\b',r'\bquick triage\b',r'\blimited triage\b',r'\binitial triage\b',r'\btriage window\b',r'\bnot run due to time\b',r'\bout of scope\b']
def read_csv(p):
    if not p.exists(): return []
    with p.open(newline='',encoding='utf-8',errors='replace') as f: return list(csv.DictReader(f))
def main():
    errors=[]; warnings=[]
    for p in REQUIRED:
        if not p.exists(): errors.append(f'Required file missing: {p}')
        elif p.stat().st_size==0: errors.append(f'Required file is empty: {p}')
    try: st=json.loads((A/'case_state.json').read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'Cannot read case_state.json: {e}'); st={}
    if st.get('analysis_mode')!='full_analysis': errors.append('case_state.json does not declare analysis_mode=full_analysis')
    if st.get('triage_reports_allowed') not in (False,'false','False',0): errors.append('triage_reports_allowed must be false')
    rows=read_csv(L/'command_ledger.csv')
    if not rows: errors.append('command_ledger.csv has no command rows')
    for i,r in enumerate(rows,start=2):
        for fld in ['UTC Time','Working Directory','Command','Stdout Path','Stderr Path','Exit Code','Notes']:
            if not r.get(fld): errors.append(f'command_ledger.csv row {i}: missing {fld}')
    reports=list(R.glob('*.md'))+list(R.glob('*.txt'))
    if not reports: warnings.append('No Markdown/text report found for language audit')
    for p in reports:
        txt=p.read_text(encoding='utf-8',errors='replace').lower()
        for pat in BAD:
            if re.search(pat,txt): errors.append(f'Banned triage/skip language found in {p}: {pat}')
    if warnings:
        print('WARNINGS:'); [print('- '+w) for w in warnings]; print()
    if errors:
        print('ERROR: final package audit failed.'); [print('- '+e) for e in errors]; return 1
    print('Final package audit passed.'); return 0
if __name__=='__main__': raise SystemExit(main())
