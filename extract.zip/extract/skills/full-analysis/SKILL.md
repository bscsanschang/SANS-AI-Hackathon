# Universal Full Analysis Skill

Use this skill for every case. This skill replaces any short-triage workflow and is platform-agnostic.

## Operating Principle

The target is every accessible datapoint, not a single OS or artifact family. Enumerate, hash, type-identify, parse, generic-scan, and raw-scan everything that can be accessed safely. For every object, either parse it with the strongest available local parser or perform a generic scan and record why type-specific parsing was not possible.

## Required Setup

```bash
./analysis/run_logged "Initialize universal full-analysis registers" python3 ./.claude/scripts/init_full_analysis_registers.py
```

`./analysis/case_state.json` must contain:

```json
{
  "analysis_mode": "full_analysis",
  "coverage_policy": "all_accessible_datapoints",
  "triage_reports_allowed": false
}
```

## Phase A - Evidence Source Discovery

Inventory every source file or evidence directory provided to the case, including disk images, split images, EWF/AFF/raw images, memory dumps, archives, loose-file collections, PCAPs, logs, databases, virtual disks, mobile backups, and cloud/sync exports.

Record every source in `./analysis/evidence_inventory.csv`.

For every evidence source, use logged discovery commands appropriate to the source:

- `file`
- `stat`
- cryptographic hashes
- `ewfinfo` / `ewfverify` for EWF
- `affinfo` / `affverify` for AFF if available
- `qemu-img info` for virtual disks if available
- `mmls` / `img_stat` for disk images if applicable
- archive listing tools for archives
- `capinfos` for PCAP if available
- `sqlite3 .schema` for SQLite databases on copied/extracted files

If a tool is missing, record `Tool Missing - Blocked` and use the best safe fallback.

## Phase B - Container, Partition, and Volume Discovery

Populate:

- `./analysis/container_inventory.csv`
- `./analysis/volume_inventory.csv`
- `./analysis/filesystem_inventory.csv`
- `./analysis/mounts.csv`

For disk images, enumerate partition tables and offsets, mount read-only where possible, and record every mount/unmount. If mounting fails, use direct read tools and record the blocker.

For archives and embedded containers, list contents first, extract only to `./exports/extracted_containers/<evidence-id>/`, and recursively analyze extracted objects as derived evidence.

For encrypted/corrupt containers, record metadata/hashes and use `Encrypted - Logged` or `Corrupt - Logged`; do not invent decrypted content.

## Phase C - Exhaustive Object Inventory

For every mounted filesystem, extracted container, loose-file evidence directory, and export root, enumerate every accessible object:

```bash
./analysis/run_logged "Enumerate, hash, and type all accessible data objects" \
  python3 ./.claude/scripts/enumerate_datapoints.py \
  --root <mounted-or-extracted-root> \
  --evidence-id <EVID-ID> \
  --inventory ./analysis/data_object_inventory.csv \
  --hash sha256
```

The inventory includes object path, type, size, SHA256, signature, extension, detected type, mode, UID/GID, timestamps, symlink target, readability, and errors.

If alternate data streams, xattrs, resource forks, or extended metadata are supported by the filesystem, enumerate them. If unsupported by tools, record `Tool Missing - Blocked` or `Not Applicable`.

## Phase D - Parser Work Queue

Build a parser work queue from the object inventory:

```bash
./analysis/run_logged "Build parser work queue" python3 ./.claude/scripts/build_parser_workqueue.py
```

Then dispatch applicable parsers for every recognized object. Do not limit parsing to Windows artifacts.

Examples:

- Disk/filesystem metadata: MFT, inode tables, APFS/HFS metadata, EXT metadata, FAT/exFAT metadata, journals, recycle/trash artifacts, deleted file records, unallocated/slack/free-space exports.
- Windows: EVTX, Registry hives, Amcache, Shimcache, BAM/DAM, SRUM, Prefetch, LNK, Jump Lists, Scheduled Tasks, Services, WMI, PowerShell, AV/EDR, browser artifacts.
- Linux: auth logs, syslog/journal, shell histories, cron/systemd timers, systemd units, SSH artifacts, account files, package logs, auditd, sudo logs, web server logs, user dotfiles, browser artifacts.
- macOS: unified logs if available, plists, LaunchAgents/LaunchDaemons, FSEvents, QuarantineEvents, Spotlight metadata, TCC.db, shell history, browser artifacts.
- Generic: SQLite, ESE, JSON/XML/YAML/INI, Office/OpenXML, PDF, email stores, archives, scripts, executables, images/media, PCAP, cloud/sync artifacts, Docker/container artifacts, virtual disks.

For each parsed object, update `./analysis/parser_dispatch.csv` and `./analysis/artifact_coverage.csv`.

## Phase E - Generic Scan for Every Unsupported File Type

A file type is never ignored. If type-specific parsing is unavailable:

```bash
./analysis/run_logged "Generic-scan all inventoried datapoints" python3 ./.claude/scripts/generic_scan_datapoints.py
```

Generic scanning includes metadata, hashes, signature/header bytes, byte/string regex scanning, IOC/YARA if available, and a recorded parser limitation. Accepted terminal status: `Unsupported - Generic Scanned`.

## Phase F - Raw Byte and Unallocated Scanning

Run raw scanning against every evidence source and every raw export that local tools can safely produce:

- original image bytes,
- memory images,
- unallocated/free-space exports,
- carved files,
- raw container bytes,
- extracted archives,
- loose evidence directories.

Use local tools when available: `bulk_extractor`, `strings`, `grep`/`rg`, `yara`, `photorec`, Sleuth Kit, and Plaso. If output is large, save full results to `./exports/` and summarize counts and paths in the report. Do not skip because output is large.

## Phase G - Timeline Generation

Generate timelines from every source type that supports timeline extraction: filesystem metadata, Plaso timelines, event/application logs, registry/plist/database timestamps, browser history, application logs, and memory artifacts where available.

## Phase H - Negative Results and Blockers

Use `./analysis/negative_results.csv` for investigated questions that return no hits. Use `./analysis/artifact_coverage.csv` for coverage state. Use `./reports/self_correction_log.jsonl` when a missed parser, contradiction, or unsupported claim is corrected.

Do not write broad absence claims unless exact artifact categories, tools, output paths, coverage windows, and limitations are documented.

## Phase I - Validation Gate

Before final report generation:

```bash
./analysis/run_logged "Validate full artifact coverage" python3 ./.claude/scripts/validate_artifact_coverage.py --full-analysis
```

If validation fails, the failure output is the next work queue. Complete or log blockers for every missing category, then rerun validation.

## Output Review Policy

After running a parser or scanner, do not read the full output.

Use this sequence:

1. Confirm command exit code from `run_logged`.
2. Record stdout/stderr paths.
3. Generate a compact summary file.
4. Read only the summary file.
5. Read exact supporting rows only when needed for a finding.

Examples:

Bad:
`cat ./exports/evtx/all_events.csv`

Good:
`python3 ./.claude/scripts/summarize_csv.py ./exports/evtx/all_events.csv --out ./analysis/evtx_summary.json`

Bad:
`grep -R "perfmon-k" ./exports/`

Good:
`grep -RIl "perfmon-k" ./exports/ > ./analysis/perfmon_k_matching_files.txt`
then summarize counts and read only matching lines from the few files that support a finding.
