---
description: Prepare SANS AI Hackathon submission artifacts including architecture, accuracy, self-correction, and execution logs.
---

# Hackathon Submission Skill

Use this skill when preparing the final contest submission package.

## Required Submission Artifacts

Create or update:

```text
./reports/final_report.md
./reports/final_report.pdf
./reports/accuracy_report.md
./reports/evidence_dataset_documentation.md
./reports/architecture_diagram.md
./reports/agent_execution_log.md
./reports/self_correction_log.jsonl
./reports/hallucination_audit.md
./reports/artifact_manifest.csv
```

## Accuracy Report

Include questions tested, expected answers if known, observed answers, supporting artifacts, unsupported or downgraded claims, false positives, false negatives, unresolved uncertainty, and how each error or uncertainty was handled.

## Self-Correction Log

Append JSONL records to `./reports/self_correction_log.jsonl`:

```json
{
  "utc": "YYYY-MM-DDTHH:MM:SSZ",
  "iteration": 1,
  "issue_detected": "",
  "source": "tool failure | contradiction | unsupported claim | missing artifact | validation script",
  "correction": "",
  "commands_run": [],
  "outcome": "",
  "remaining_limitation": ""
}
```

## Architecture Diagram

Document the instruction layer, enforced controls, logged command wrapper, evidence inputs, parser layer, registers, outputs, and validation gates. Markdown Mermaid is acceptable for `architecture_diagram.md`.

## Execution Log

`./reports/agent_execution_log.md` should summarize session date, timezone basis, model/tooling environment if available, major phases completed, command-ledger path, total commands logged, failed commands, reruns/retries, validation gates, known limitations, and token/cost telemetry if available.

## Synthetic Flag Exception

If a hackathon/CTF-style synthetic flag or answer token is discovered, record it in `./reports/contest_answers.md`. Do not treat synthetic flags as real credentials.
