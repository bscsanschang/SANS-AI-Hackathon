# Claim Validation Skill - Universal Full Analysis

Coverage-complete analysis does not justify stronger claims. It only improves the search scope. Every claim still requires artifact-backed support.

## Split Observation From Interpretation

Bad: `C:\Windows\subject_srv.exe is an authorized forensic tool.`

Good:

- Direct Observation: `C:\Windows\subject_srv.exe exists and has hash <hash>.`
- Supported Inference: `Strings/service metadata are consistent with F-Response Subject.`
- Unknown: `Authorization is not independently determined unless supported by case notes.`

## Finding Register Requirement

Each `./analysis/finding_register.jsonl` record must include finding_id, claim, claim_type, confidence, evidence_ids, artifact_refs, tool_output_paths, supporting_evidence, contradictory_evidence, missing_evidence, alternative_explanations, disproof_conditions, coverage_dependencies, and report_ready.

## Coverage Dependency Rule

Every major finding must identify coverage categories that support or limit it. If a relevant coverage category has a blocker, downgrade confidence and state the limitation.

## Evidence Thresholds

Do not escalate artifact presence to attribution, intent, compromise, exfiltration, credential theft, pass-the-hash, persistence, lateral movement, or host compromise without explicit supporting evidence.

## Absence Claims

Do not write broad claims such as no malware, no C2, no persistence, no lateral movement, no exfiltration, or no credential access. Preferred wording: `No relevant evidence was identified in the artifacts reviewed and listed in the coverage matrix.`

Every absence claim must name artifact categories searched, tools/parsers used, output paths, coverage windows, and limitations.
