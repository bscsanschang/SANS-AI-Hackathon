---
description: Verify disk and memory evidence, build evidence inventory, and record tool versions without writing to evidence.
---

# Evidence Verification Skill

Use this skill when identifying, verifying, or inventorying disk images, memory images, exported artifacts, or tool availability.

## Rules

- All commands must run through `./analysis/run_logged`.
- Never write to evidence directories.
- Every evidence item receives a stable Evidence ID before findings reference it.
- Use UTC timestamps.
- Save inventories to `./analysis/evidence_inventory.csv` and `./analysis/tool_inventory.csv`.

## Tool Inventory

Record the expected invocation, resolved path, version command, version output, status, and notes in `./analysis/tool_inventory.csv`.

Recommended checks:

```bash
./analysis/run_logged "Verify Volatility 3 path" test -f /opt/volatility3-2.20.0/vol.py
./analysis/run_logged "Verify dotnet runtime" /usr/bin/dotnet --info
./analysis/run_logged "Verify Sleuth Kit tools" bash -o pipefail -lc 'command -v fls && command -v mmls && command -v icat && command -v img_stat'
./analysis/run_logged "Verify EWF tools" bash -o pipefail -lc 'command -v ewfinfo && command -v ewfverify && command -v ewfmount'
./analysis/run_logged "Verify Plaso tools" bash -o pipefail -lc 'command -v log2timeline.py && command -v psort.py && command -v pinfo.py'
./analysis/run_logged "Verify YARA" /usr/local/bin/yara --version
```

## Disk Evidence

For every disk image, run at minimum:

```bash
./analysis/run_logged "Identify disk image type" file <image>
./analysis/run_logged "EWF metadata" ewfinfo <image.E01>
./analysis/run_logged "EWF verification" ewfverify <image.E01>
./analysis/run_logged "Image statistics" img_stat <image-or-mounted-ewf>
./analysis/run_logged "Partition table" mmls <image-or-mounted-ewf>
```

Record hashes, sector size, partition offsets, verification status, and limitations.

## Memory Evidence

For every memory image, run at minimum:

```bash
./analysis/run_logged "Identify memory image type" file <memory-image>
./analysis/run_logged "Volatility 3 windows.info" python3 /opt/volatility3-2.20.0/vol.py -f <memory-image> windows.info
```

If symbols or layers fail, record the exact error as a limitation. Do not switch to `/usr/local/bin/vol.py`.

## Evidence ID Convention

Use stable IDs such as:

```text
EVID-DISK-001
EVID-MEM-001
EVID-EXPORT-001
```

Every finding must reference one or more Evidence IDs.
