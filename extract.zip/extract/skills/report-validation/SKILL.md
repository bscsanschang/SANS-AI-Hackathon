# Report Validation Skill - Universal Full Analysis

Final reporting is invalid unless this command passes:

```bash
./analysis/run_logged "Validate full artifact coverage" python3 ./.claude/scripts/validate_artifact_coverage.py --full-analysis
```

Do not convert a failed coverage validation into a limitation statement. Fix the missing analysis or record an accepted terminal blocker in `./analysis/artifact_coverage.csv`.

## Required Final Report Sections

The final report must include Executive Summary, Scope and Evidence, Analysis Mode statement, Methodology, Tool Inventory, Evidence Integrity, Container/Volume/Filesystem Coverage, Universal Artifact Coverage Matrix, Data Object Inventory Summary, Parser Dispatch Summary, Raw Byte Scan Summary, Timeline, Findings, IOC/Investigative Leads, Negative Results, Open Hypotheses, Gaps/Blockers/Limitations, Claim Support Matrix, Reproducibility Appendix, Command Ledger Summary, Artifact Manifest Summary, and Confidence Definitions.

## Universal Artifact Coverage Matrix

Minimum columns:

```text
Evidence ID | Scope | Category | Source Path | Method/Parser | Output Path | Summary Path | Status | Limitation | Command ledger reference
```

Every required universal category must appear with an accepted terminal status.

Invalid final-report statuses: Skipped, Not parsed, Not run, Pending, Deferred, Out of scope, Triage only, Triage window, Partial, blank.

## Data Object Inventory Summary

Summarize `./analysis/data_object_inventory.csv`: total objects, regular files, directories, unreadable objects, total bytes hashed/scanned, file type distribution, largest files, unknown/unsupported types, and derived object count. Reference the full inventory path instead of pasting it.

## Parser Dispatch Summary

Summarize `./analysis/parser_dispatch.csv`: recognized objects, parsed objects, unsupported objects generically scanned, parser failures, missing tools, encrypted/corrupt objects, and output locations.

## Raw Byte Scan Summary

Summarize `./analysis/raw_scan_register.csv`: source scanned, method, scope, output path, hit counts, and limitations. Coverage must include original evidence images and extracted raw/unallocated/memory/container bytes where accessible.

## Claim Support Matrix

Required columns:

```text
Finding ID | Claim | Claim Type | Confidence | Evidence ID | Supporting Evidence | Tool Output Path | Alternative Explanation | Limitation
```

Every executive-summary claim must map to a finding ID. Every finding ID must map to exact tool output paths or appendix path IDs.

## Path Rules

Final reports must use exact paths. Do not use `...`, `./analysis/...`, `./exports/...`, `./logs/...`, shortened paths, or placeholder paths. If a path is too long, use an appendix path ID.

## Hash Column Rules

Columns labeled MD5, SHA1, SHA-1, SHA256, or SHA-256 must contain full valid hashes or `NOT_COMPUTED`, `NOT_AVAILABLE`, `DELETED_NOT_RECOVERED`, or `SEE_APPENDIX`. If shortened, the header must say `(truncated)` and point to the full hash source.

## Language Audit

Search the report for: attacker, compromise, compromised, malware, trojan, backdoor, keylogger, exfiltration, stolen, pass-the-hash, persistence, lateral movement, command and control, C2, beacon, spawned, installed by, downloaded by, deleted by, authorized, expected, confirmed, root cause, initial access, malicious.

For every use, verify the evidence threshold, confidence, alternative explanation, and whether wording must be downgraded.

## Final Package Audit

After report, manifest, and PDF generation:

```bash
./analysis/run_logged "Final full-analysis package audit" python3 ./.claude/scripts/final_package_audit.py
```

Do not modify deliverables after the final package audit unless another audit is run.

## Output Review Policy

After running a parser or scanner, do not read the full output.

Use this sequence:

1. Confirm command exit code from `run_logged`.
2. Record stdout/stderr paths.
3. Generate a compact summary file.
4. Read only the summary file.
5. Read exact supporting rows only when needed for a finding.

Examples:

Bad:
`cat ./exports/evtx/all_events.csv`

Good:
`python3 ./.claude/scripts/summarize_csv.py ./exports/evtx/all_events.csv --out ./analysis/evtx_summary.json`

Bad:
`grep -R "perfmon-k" ./exports/`

Good:
`grep -RIl "perfmon-k" ./exports/ > ./analysis/perfmon_k_matching_files.txt`
then summarize counts and read only matching lines from the few files that support a finding.
